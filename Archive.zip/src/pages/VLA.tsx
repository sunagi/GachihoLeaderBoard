import VLALeaderBoad from "../components/VLA";

export default function NFTForesightLanking() {
    return (
        <>
            <h1>VeryLongAnimals</h1>
            <VLALeaderBoad />
        </>
    )
}
